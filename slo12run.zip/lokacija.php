<?php include 'head.php';?>
    <main>
        <div class="besedilop">
            <h2>Lokacija</h2>

            <p>SLOVENIAN 12 HOUR RUN</p>
            <p>4000 Kranj</p>
            <p>Klemen Boštar</p>
            <p>070 - 878 498</p>
            <p>klemen.botar@gmail.com</p>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2759.574112193128!2d14.3533639149171!3d46.2388134791178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477ab81d352ba639%3A0xf59ddc9f98087d7e!2sGlavni%20trg%2C%204000%20Kranj!5e0!3m2!1ssl!2ssi!4v1586184676822!5m2!1ssl!2ssi" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
        
        <?php include 'footer.php';?>