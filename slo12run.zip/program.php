<?php include 'head.php';?>
    <main>
        <div class="besedilop">
            <h2>Program</h2>
            <p>kraj tekmovanja ... KRANJ- Glavni trg</p>
            <p>čas prireditve ... SOBOTA 4.7. - NEDELJA, 5. 7. 2020</p>
            <h3>Sobota</h3>
            <p>16:00 - 19:00 ... Sejem rabljene športne opreme</p>
            <p>19:00 - 19:30 ... Prevzem štartnih številk</p>
            <p>19:30 - 20:30 ... Pasta party</p>
            <h3>Nedelja</h3>
            <p>06:00 - 06:30 ... Prevzem štartnih številk</p>
            <p>6:30 - 6:45 ... Zadnji napotki tekačem s strani organizatorja</p>
            <p><b>7:00 ... Start 12-urnega teka</b></p>
            <p><b>13:00 ... Start 6-urnega teka</b></p>
            <p>19:00 ... Zaključek 6 in 12-urnega teka</p>
            <p>20:00 ... Podelitev nagrad in priznanj (6 in 12 ur)</p>
            <p>20:30 ... Pozdrav župana Občine Kranj</p>
            <p>od 20:30 dalje ... Žur</p>
        </div>
        
        <?php include 'footer.php';?>