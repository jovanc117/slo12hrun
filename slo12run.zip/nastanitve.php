<?php include 'head.php';?>
    <main>
        <div class="besedilop">
            <h2>Nastanitev</h2>
            <h3>Gostilna Stari Mayr</h3>
            <p>Lokacija: 20 metrov od starta</p>
            <p>Cena: 35 eur/osebo (nočitev + zajtrk)</p>
            <p>Rezervacije: klemen.botar@gmail.com</p>
            <img class="nastanitev" src="slike/nastanitev.jpg" alt="nastanitev">
        </div>
        <?php include 'footer.php';?>